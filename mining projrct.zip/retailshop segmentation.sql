-- create schema retailshop;
use retailshop; 
select *from online_retail;
-- Distribute the order value first calculate the order value and then distribute
SELECT CustomerID,
    SUM(Quantity * UnitPrice) AS OrderValue
FROM online_retail
GROUP BY CustomerID;
SELECT 
case when TotalOrderValue < 50 then 'Low Spender'
when TotalOrderValue between 50 and 200 then 'Medium Spender'
else 'High Spender' end as SpendingCategory,
count(CustomerID) as NumberofCustomers
FROM (SELECT CustomerID,
SUM(Quantity * UnitPrice) as TotalOrderValue
FROM online_retail
GROUP by CustomerID) as subquery
Group by SpendingCategory;


-- unique product customer purchased
select CustomerID,count(distinct StockCode)  as UniqueProductPurchased
from
   online_retail
Group by customerID;


-- which customer have only single purchase from the company
select
 CustomerID,count(distinct InvoiceNo) as NumberofPurchases
from 
  online_retail
group by  CustomerID
having Numberofpurchases = 1;


 -- 5 product most commonly purchased together
select
 p1.Stockcode as product1,
p2.Stockcode as product2,
count(*) as TimePurchasedTogether 
from
   online_retail p1
join online_retail p2 on p1.InvoiceNo = p2.InvoiceNo and p1.Stockcode < p2.StockCode
group by p1.StockCode, p2.StockCode
order by TimePurchasedTogether desc;

   -- ADVANCED QUERIES 
select 
  CustomerID,count(distinct InvoiceNo) as PurchaseFrequency
from 
  online_retail 
group by
   CustomerID;

select 
   CustomerID, PurchaseFrequency,
case 
when purchaseFrequency <=2 then 'Low Frequency'
when PurchaseFrequency between 3 and 5 then 'Medium Frequency'
else 'High Frequency' end as FrequencySegment
from 
	(select CustomerID, count(distinct InvoiceNo)
as PurchaseFrequency
from online_retail
group by CustomerID) as FrequencyTable;

-- calculate the average order value for each country
select country, avg (TotalOrderValue) as AverageOrderValue
from 
    (select InvoiceNo,Country,sum(Quantity * UnitPrice) as TotalOrderValue
from 
	online_retail
group by InvoiceNo,Country) as TotalOrderValue
group by Country
order by AverageOrderValue desc;

-- identify customers who have not made a purchase in specific period
with LastPurchase as ( select CustomerID, max(InvoiceDate) as LastPurchaseDate
from 
   online_retail
group by CustomerID)
select 
   CustomerID, LastPurchaseDate
from 
   LastPurchase
where LastPurchaseDate<'2024-03-01';


-- Identify customers who haven't made a purchase in a specific period (e.g., last 6 months) to assess churn.
SELECT CustomerID, MAX(InvoiceDate) AS LastPurchaseDate
FROM online_retail
GROUP BY CustomerID
HAVING MAX(InvoiceDate) < NOW() - INTERVAL 5 MONTH;

 -- Determine which products are often purchased together by calculating the correlation between product purchases.
  select  a.StockCode AS Product_2,
    b.StockCode AS Product_1,
    COUNT(DISTINCT a.InvoiceNo) AS TogetherCount
FROM  online_retail a 
JOIN  online_retail b 
    ON a.InvoiceNo = b.InvoiceNo
    AND a.StockCode != b.StockCode
GROUP BY Product_1, Product_2
ORDER BY TogetherCount DESC;


  -- Explore trends in customer behavior over time, such as monthly or quarterly sales patterns.
 SELECT 
    EXTRACT(YEAR FROM InvoiceDate) AS Year,
    EXTRACT(MONTH FROM InvoiceDate) AS Month,
    SUM(Quantity * UnitPrice) AS TotalSales
FROM online_retail
GROUP BY Year, Month
ORDER BY Year, Month;

                                               -- THE END

